<?php

namespace App\Controller;

class BaseController {
    
}
?>