<?php
    include_once('../BaseController.php');
    include_once('../../model/config/ActionModel.php');

    class ActionController extends BaseController {
        public function __construct() {
            
        }

        public function store($data) {

        }

        public function show($data) {

        }

        public function update($data) {

        }

        public function destroy($data) {

        }
    }
?>