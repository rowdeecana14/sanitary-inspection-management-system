<?php
    include_once('../BaseModel.php.php');

    class ActionModel extends BaseModel {
        public function __construct() {
            
        }

        public function store($data) {

        }

        public function show($data) {

        }

        public function update($data) {

        }

        public function destroy($data) {

        }
    }
?>